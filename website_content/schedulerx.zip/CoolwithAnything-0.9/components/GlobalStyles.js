import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white', // Set a default background color if needed
  },
  text: {
    color: 'black', // Set a default text color if needed
  },
});
